export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          changed_by: string | null
          changed_by_email: string | null
          created_at: string
          declaration_id: string | null
          declaration_number: string | null
          id: string
          new_values: Json | null
          old_values: Json | null
        }
        Insert: {
          action: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          declaration_id?: string | null
          declaration_number?: string | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
        }
        Update: {
          action?: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          declaration_id?: string | null
          declaration_number?: string | null
          id?: string
          new_values?: Json | null
          old_values?: Json | null
        }
        Relationships: []
      }
      declaration_items: {
        Row: {
          country_of_origin: string | null
          created_at: string
          currency: string
          declaration_id: string
          description: string
          hs_code: string | null
          id: string
          position: number
          quantity: number | null
          unit: string | null
          unit_value: number | null
          updated_at: string
        }
        Insert: {
          country_of_origin?: string | null
          created_at?: string
          currency?: string
          declaration_id: string
          description: string
          hs_code?: string | null
          id?: string
          position?: number
          quantity?: number | null
          unit?: string | null
          unit_value?: number | null
          updated_at?: string
        }
        Update: {
          country_of_origin?: string | null
          created_at?: string
          currency?: string
          declaration_id?: string
          description?: string
          hs_code?: string | null
          id?: string
          position?: number
          quantity?: number | null
          unit?: string | null
          unit_value?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "declaration_items_declaration_id_fkey"
            columns: ["declaration_id"]
            isOneToOne: false
            referencedRelation: "import_declarations"
            referencedColumns: ["id"]
          },
        ]
      }
      declaration_payments: {
        Row: {
          amount_birr: number
          basis: Database["public"]["Enums"]["payment_basis"]
          collected_by: string | null
          collected_on: string
          created_at: string
          declaration_id: string
          id: string
          note: string | null
          other_reason: string | null
          position: number
          updated_at: string
        }
        Insert: {
          amount_birr?: number
          basis?: Database["public"]["Enums"]["payment_basis"]
          collected_by?: string | null
          collected_on?: string
          created_at?: string
          declaration_id: string
          id?: string
          note?: string | null
          other_reason?: string | null
          position?: number
          updated_at?: string
        }
        Update: {
          amount_birr?: number
          basis?: Database["public"]["Enums"]["payment_basis"]
          collected_by?: string | null
          collected_on?: string
          created_at?: string
          declaration_id?: string
          id?: string
          note?: string | null
          other_reason?: string | null
          position?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "declaration_payments_declaration_id_fkey"
            columns: ["declaration_id"]
            isOneToOne: false
            referencedRelation: "import_declarations"
            referencedColumns: ["id"]
          },
        ]
      }
      import_declarations: {
        Row: {
          assigned_agent: string | null
          attachments: Json
          bill_of_lading_number: string | null
          commodity: string
          contact_email: string
          contact_phone: string
          created_at: string
          created_by: string | null
          date_cleared_customs: string | null
          date_exited_port: string | null
          date_submitted: string
          declaration_number: string
          declaration_status: Database["public"]["Enums"]["declaration_status"]
          health_ministry_app_no: string | null
          hs_code: string | null
          id: string
          importer_name: string
          importer_tin: string
          last_updated: string
          national_bank_cleared_date: string | null
          remarks: string | null
          trade_ministry_app_no: string | null
        }
        Insert: {
          assigned_agent?: string | null
          attachments?: Json
          bill_of_lading_number?: string | null
          commodity: string
          contact_email: string
          contact_phone: string
          created_at?: string
          created_by?: string | null
          date_cleared_customs?: string | null
          date_exited_port?: string | null
          date_submitted?: string
          declaration_number: string
          declaration_status?: Database["public"]["Enums"]["declaration_status"]
          health_ministry_app_no?: string | null
          hs_code?: string | null
          id?: string
          importer_name: string
          importer_tin: string
          last_updated?: string
          national_bank_cleared_date?: string | null
          remarks?: string | null
          trade_ministry_app_no?: string | null
        }
        Update: {
          assigned_agent?: string | null
          attachments?: Json
          bill_of_lading_number?: string | null
          commodity?: string
          contact_email?: string
          contact_phone?: string
          created_at?: string
          created_by?: string | null
          date_cleared_customs?: string | null
          date_exited_port?: string | null
          date_submitted?: string
          declaration_number?: string
          declaration_status?: Database["public"]["Enums"]["declaration_status"]
          health_ministry_app_no?: string | null
          hs_code?: string | null
          id?: string
          importer_name?: string
          importer_tin?: string
          last_updated?: string
          national_bank_cleared_date?: string | null
          remarks?: string | null
          trade_ministry_app_no?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          declaration_id: string | null
          declaration_number: string | null
          id: string
          recipient_email: string
          status: string
          subject: string
        }
        Insert: {
          body: string
          created_at?: string
          declaration_id?: string | null
          declaration_number?: string | null
          id?: string
          recipient_email: string
          status?: string
          subject: string
        }
        Update: {
          body?: string
          created_at?: string
          declaration_id?: string | null
          declaration_number?: string | null
          id?: string
          recipient_email?: string
          status?: string
          subject?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "client"
      declaration_status:
        | "Submitted"
        | "Paid"
        | "Cleared"
        | "Exited"
        | "Cancelled"
        | "National Bank Cleared"
      payment_basis: "Per truck" | "Per declaration" | "Other"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "client"],
      declaration_status: [
        "Submitted",
        "Paid",
        "Cleared",
        "Exited",
        "Cancelled",
        "National Bank Cleared",
      ],
      payment_basis: ["Per truck", "Per declaration", "Other"],
    },
  },
} as const
